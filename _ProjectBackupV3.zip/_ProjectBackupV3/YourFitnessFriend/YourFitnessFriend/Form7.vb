﻿Imports MySql.Data.MySqlClient
Public Class Form7
    Private Sub BtnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLoad.Click
        Dim fitness As Fitness
        Dim connection As MySqlConnection
        Dim command As MySqlCommand
        Dim connectionString As String = "server=localhost;user=root;password=;database=YourFitnessFriend"
        Dim reader As MySqlDataReader
        Dim calories As Integer

        connection = New MySqlConnection(connectionString)
        connection.Open()

        command = New MySqlCommand("SELECT * FROM FitnessData, UserLogin WHERE FitnessData.userId = UserLogin.userId AND FitnessData.userId = '" & EnterID.Text & "'")
        command.Connection = connection
        reader = command.ExecuteReader

        While reader.Read()
            fitness.LoseOrGain = reader.Item("LoseOrGain")
            fitness.FitnessGoal = reader.Item("FitnessGoal")
            calories = fitness.FitnessGoal

            If fitness.LoseOrGain = "Lose" Then
                LstDisplayLoseOrGain.Items.Add("To lose weight you must be on a calorie deficit by eating the same amount of calories as your fitness goal.")
                LstDisplayLoseOrGain.Items.Add("You should aim to eat around " & calories & " calroies per day.")
                LstDisplayLoseOrGain.Items.Add("")
                LstDisplayLoseOrGain.Items.Add("Top that off with regular exercise, accountability and patience")
            ElseIf fitness.LoseOrGain = "Gain" Then
                LstDisplayLoseOrGain.Items.Add("To gain weight you must be on a calorie surplus by eating the same amount of calories as your fitness goal.")
                LstDisplayLoseOrGain.Items.Add("You should aim to eat around " & calories & " calroies per day.")
                LstDisplayLoseOrGain.Items.Add("")
                LstDisplayLoseOrGain.Items.Add("Top that off with regular exercise, accountability and patience")
            End If
        End While

        LstDisplayMuscle.Items.Add("To gain muscle you must eat alot of protein")
        LstDisplayMuscle.Items.Add("")
        LstDisplayMuscle.Items.Add("Here are some high protein foods you can")
        LstDisplayMuscle.Items.Add("incorporate into your diet:")
        LstDisplayMuscle.Items.Add("")
        LstDisplayMuscle.Items.Add("- Eggs")
        LstDisplayMuscle.Items.Add("- Chicken")
        LstDisplayMuscle.Items.Add("- Beef")
        LstDisplayMuscle.Items.Add("- Fish")

        LstDisplayGym.Items.Add("Push:")
        LstDisplayGym.Items.Add("")
        LstDisplayGym.Items.Add("Bench Press")
        LstDisplayGym.Items.Add("DB Press")
        LstDisplayGym.Items.Add("Shoulder Press")
        LstDisplayGym.Items.Add("Tricep Cable Pulldown")
        LstDisplayGym.Items.Add("")
        LstDisplayGym.Items.Add("Pull:")
        LstDisplayGym.Items.Add("Bicep Curls")
        LstDisplayGym.Items.Add("Rows")
        LstDisplayGym.Items.Add("Deadlift")
        LstDisplayGym.Items.Add("Lat Pulldown")
        LstDisplayGym.Items.Add("")
        LstDisplayGym.Items.Add("Legs:")
        LstDisplayGym.Items.Add("")
        LstDisplayGym.Items.Add("Squats")
        LstDisplayGym.Items.Add("Lunge")
        LstDisplayGym.Items.Add("Leg Extention")
        LstDisplayGym.Items.Add("Calf Raises ")

        LstDisplayCardio.Items.Add("Best Low Intensity Cardio Exercises")
        LstDisplayCardio.Items.Add("")
        LstDisplayCardio.Items.Add("Cycling")
        LstDisplayCardio.Items.Add("Walking on Incline")
        LstDisplayCardio.Items.Add("Stair Climbing")

        connection.Close()
    End Sub

    Private Sub BtnHome_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnHome.Click
        LstDisplayLoseOrGain.Items.Clear()
        LstDisplayGym.Items.Clear()
        LstDisplayMuscle.Items.Clear()
        LstDisplayCardio.Items.Clear()
        EnterID.Clear()
        Me.Hide()
        Form3.Show()
    End Sub
End Class