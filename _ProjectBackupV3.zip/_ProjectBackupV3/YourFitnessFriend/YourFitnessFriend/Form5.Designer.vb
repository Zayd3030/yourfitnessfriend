﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form5))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BtnHome = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ComboBoxGender = New System.Windows.Forms.ComboBox()
        Me.TextBoxWeight = New System.Windows.Forms.TextBox()
        Me.TextBoxAge = New System.Windows.Forms.TextBox()
        Me.TextBoxHeight = New System.Windows.Forms.TextBox()
        Me.ComboBoxExercise = New System.Windows.Forms.ComboBox()
        Me.ComboBoxLoseOrGain = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LstDisplayBMR = New System.Windows.Forms.ListBox()
        Me.LstDisplayFG = New System.Windows.Forms.ListBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.BtnFitnessData = New System.Windows.Forms.Button()
        Me.EnterUsername = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(302, 84)
        Me.PictureBox1.TabIndex = 17
        Me.PictureBox1.TabStop = False
        '
        'BtnHome
        '
        Me.BtnHome.Image = CType(resources.GetObject("BtnHome.Image"), System.Drawing.Image)
        Me.BtnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnHome.Location = New System.Drawing.Point(738, 12)
        Me.BtnHome.Name = "BtnHome"
        Me.BtnHome.Size = New System.Drawing.Size(167, 47)
        Me.BtnHome.TabIndex = 21
        Me.BtnHome.Text = "Home"
        Me.BtnHome.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(333, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(320, 41)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Enter Fitness Data"
        '
        'ComboBoxGender
        '
        Me.ComboBoxGender.FormattingEnabled = True
        Me.ComboBoxGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.ComboBoxGender.Location = New System.Drawing.Point(94, 188)
        Me.ComboBoxGender.Name = "ComboBoxGender"
        Me.ComboBoxGender.Size = New System.Drawing.Size(138, 21)
        Me.ComboBoxGender.TabIndex = 23
        '
        'TextBoxWeight
        '
        Me.TextBoxWeight.Location = New System.Drawing.Point(271, 188)
        Me.TextBoxWeight.Name = "TextBoxWeight"
        Me.TextBoxWeight.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxWeight.TabIndex = 24
        '
        'TextBoxAge
        '
        Me.TextBoxAge.Location = New System.Drawing.Point(553, 189)
        Me.TextBoxAge.Name = "TextBoxAge"
        Me.TextBoxAge.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxAge.TabIndex = 25
        '
        'TextBoxHeight
        '
        Me.TextBoxHeight.Location = New System.Drawing.Point(410, 188)
        Me.TextBoxHeight.Name = "TextBoxHeight"
        Me.TextBoxHeight.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxHeight.TabIndex = 26
        '
        'ComboBoxExercise
        '
        Me.ComboBoxExercise.FormattingEnabled = True
        Me.ComboBoxExercise.Items.AddRange(New Object() {"Sedentary", "Lightly", "Moderately", "VeryActive", "ExtraActive"})
        Me.ComboBoxExercise.Location = New System.Drawing.Point(698, 189)
        Me.ComboBoxExercise.Name = "ComboBoxExercise"
        Me.ComboBoxExercise.Size = New System.Drawing.Size(138, 21)
        Me.ComboBoxExercise.TabIndex = 27
        '
        'ComboBoxLoseOrGain
        '
        Me.ComboBoxLoseOrGain.FormattingEnabled = True
        Me.ComboBoxLoseOrGain.Items.AddRange(New Object() {"Lose", "Gain"})
        Me.ComboBoxLoseOrGain.Location = New System.Drawing.Point(391, 273)
        Me.ComboBoxLoseOrGain.Name = "ComboBoxLoseOrGain"
        Me.ComboBoxLoseOrGain.Size = New System.Drawing.Size(138, 21)
        Me.ComboBoxLoseOrGain.TabIndex = 28
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(126, 166)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(65, 19)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "Gender" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(271, 166)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 19)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Weight (KG)"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(401, 251)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(118, 19)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "Lose Or Gain?"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(734, 166)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 19)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Exercise" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(582, 166)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 19)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "Age" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(412, 166)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(98, 19)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Height (CM)"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LstDisplayBMR
        '
        Me.LstDisplayBMR.FormattingEnabled = True
        Me.LstDisplayBMR.Location = New System.Drawing.Point(41, 306)
        Me.LstDisplayBMR.Name = "LstDisplayBMR"
        Me.LstDisplayBMR.Size = New System.Drawing.Size(191, 95)
        Me.LstDisplayBMR.TabIndex = 35
        '
        'LstDisplayFG
        '
        Me.LstDisplayFG.FormattingEnabled = True
        Me.LstDisplayFG.Location = New System.Drawing.Point(645, 306)
        Me.LstDisplayFG.Name = "LstDisplayFG"
        Me.LstDisplayFG.Size = New System.Drawing.Size(191, 95)
        Me.LstDisplayFG.TabIndex = 36
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(109, 275)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 19)
        Me.Label8.TabIndex = 37
        Me.Label8.Text = "BMR"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(694, 275)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(104, 19)
        Me.Label9.TabIndex = 38
        Me.Label9.Text = "Fitness Goal"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BtnFitnessData
        '
        Me.BtnFitnessData.Image = CType(resources.GetObject("BtnFitnessData.Image"), System.Drawing.Image)
        Me.BtnFitnessData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnFitnessData.Location = New System.Drawing.Point(318, 316)
        Me.BtnFitnessData.Name = "BtnFitnessData"
        Me.BtnFitnessData.Size = New System.Drawing.Size(271, 85)
        Me.BtnFitnessData.TabIndex = 39
        Me.BtnFitnessData.Text = "Calculate"
        Me.BtnFitnessData.UseVisualStyleBackColor = True
        '
        'EnterUsername
        '
        Me.EnterUsername.Location = New System.Drawing.Point(410, 113)
        Me.EnterUsername.Name = "EnterUsername"
        Me.EnterUsername.Size = New System.Drawing.Size(100, 20)
        Me.EnterUsername.TabIndex = 40
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(397, 91)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(132, 19)
        Me.Label10.TabIndex = 41
        Me.Label10.Text = "Enter Username"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(164, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(917, 443)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.EnterUsername)
        Me.Controls.Add(Me.BtnFitnessData)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.LstDisplayFG)
        Me.Controls.Add(Me.LstDisplayBMR)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.ComboBoxLoseOrGain)
        Me.Controls.Add(Me.ComboBoxExercise)
        Me.Controls.Add(Me.TextBoxHeight)
        Me.Controls.Add(Me.TextBoxAge)
        Me.Controls.Add(Me.TextBoxWeight)
        Me.Controls.Add(Me.ComboBoxGender)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.BtnHome)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form5"
        Me.Text = "Form5"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents BtnHome As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ComboBoxGender As System.Windows.Forms.ComboBox
    Friend WithEvents TextBoxWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxAge As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxHeight As System.Windows.Forms.TextBox
    Friend WithEvents ComboBoxExercise As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBoxLoseOrGain As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LstDisplayBMR As System.Windows.Forms.ListBox
    Friend WithEvents LstDisplayFG As System.Windows.Forms.ListBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents BtnFitnessData As System.Windows.Forms.Button
    Friend WithEvents EnterUsername As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
End Class
