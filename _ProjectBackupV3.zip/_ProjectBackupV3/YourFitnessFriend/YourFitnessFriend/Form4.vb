﻿Public Class Form4

    Private Sub BtnYes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnYes.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub BtnNo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnNo.Click
        Me.Hide()
        Form3.Show()
    End Sub
End Class