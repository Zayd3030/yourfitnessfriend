﻿Imports MySql.Data.MySqlClient
Public Structure Fitness
    Public id As Integer
    Public Gender As String
    Public Weight As Integer
    Public Height As Integer
    Public Age As Integer
    Public Exercise As String
    Public LoseOrGain As String
    Public BMR As Integer
    Public ExerciseBMR As Integer
    Public FitnessGoal As Integer
End Structure
Public Class Form6
    Private Sub BtnHome_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnHome.Click
        LstDisplayGoal.Items.Clear()
        LstDisplayAS.Items.Clear()
        LstDisplayDP.Items.Clear()
        EnterID.Clear()
        Me.Hide()
        Form3.Show()
    End Sub

    Private Sub BtnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLoad.Click
        Dim fitness As Fitness
        Dim connection As MySqlConnection
        Dim command As MySqlCommand
        Dim connectionString As String = "server=localhost;user=root;password=;database=YourFitnessFriend"
        Dim reader As MySqlDataReader
        Dim myRnd As Integer
        Dim days As Integer

        connection = New MySqlConnection(connectionString)
        connection.Open()

        command = New MySqlCommand("SELECT * FROM FitnessData, UserLogin WHERE FitnessData.userId = UserLogin.userId AND FitnessData.userId = '" & EnterID.Text & "'")
        command.Connection = connection
        reader = command.ExecuteReader

        While reader.Read()
            fitness.FitnessGoal = reader.Item("FitnessGoal")
            Call InsertionSort()
            LstDisplayGoal.Items.Add("Your Fitness Goal is " & fitness.FitnessGoal & " Calories ")

            fitness.Exercise = reader.Item("Exercise")

            If fitness.Exercise = "Sedentary" Then
                days = 3
            ElseIf fitness.Exercise = "Lightly" Then
                days = 3
            ElseIf fitness.Exercise = "Moderately" Then
                days = 4
            ElseIf fitness.Exercise = "VeryActive" Then
                days = 5
            ElseIf fitness.Exercise = "ExtraActive" Then
                days = 6
            End If

            LstDisplayAS.Items.Add("Action Steps: ")
            LstDisplayAS.Items.Add("")
            LstDisplayAS.Items.Add("- You Should be increasing your exercise and aim to go to the gym " & days & " Times a Week")
            LstDisplayAS.Items.Add("")
            LstDisplayAS.Items.Add("- Do your best to record your calories and try to hit your calorie goal everyday")
            LstDisplayAS.Items.Add("")
            LstDisplayAS.Items.Add("- Start off slow. Slow, steady progress is better than no progress at all. We must crawl before we walk and walk before we run")
            LstDisplayAS.Items.Add("")
            LstDisplayAS.Items.Add("- Make sure to keep accountable at all times")


            myRnd = CInt(Int((5 * Rnd()) + 1))

            If fitness.FitnessGoal > 2500 Then
                LstDisplayDP.Items.Add("Diet Plan: ")
                LstDisplayDP.Items.Add("")
                If myRnd = 1 Then
                    LstDisplayDP.Items.Add("Breakfast – One scoop of whey protein, 20 grams of blueberries, 2 whole eggs and 5 egg whites.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack – 2 small bananas and one scoop of protein powder")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch – 125 g of cooked brown rice, 198 g of cooked chicken breast, 80 g of mixed salad (vegetables of your choice).")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Afternoon snack– 4 boiled egg whites, 1 apple and 2 scoops of whey protein powder (mixed with water).")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dinner – 198 g of chicken breast, 60 g of sweet potato and 80 g of mixed salad.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Total intake for the day: Calories: 2,347. Fat: 32 g, Carbs: 159 g, Protein: 285.8 g")
                ElseIf myRnd = 2 Then
                    LstDisplayDP.Items.Add("Breakfast – 268 g of egg whites, two slices of sprouted bread, reduced sugar jam and sugar-free ketchup.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack – Protein bar (68 g) and black coffee.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch – 74 g of oats, one medium-sized banana, 10 g of coconut flakes and 3 pieces of 70% dark chocolate.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack – One large nectarine.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch #2 – 150 g lean ground beef, 1 cup of cauliflower florets, 150 g of Jasmine rice and 1 tbsp hoisin sauce.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dinner – 1 cup of broccoli florets, 1 can of tuna and one medium-size sweet potato (baked).")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dessert – 2 low-calorie ice cream bars.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Total intake for the day:  Calories: 2,413. Fat: 69.3 g, Carbs: 311.9 g, Protein: 193.7 g")
                ElseIf myRnd = 3 Then
                    LstDisplayDP.Items.Add("Breakfast – 2 6-inch buttermilk pancakes, 2 slices bacon, 2 pats butter, 3 tbsp pure maple syrup.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack – 1 medium banana and 1 cup oatmeal.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch – 1 bagel, 113 g sliced turkey, 2 slices tomato, 1 lettuce leaf, 1 slice cheddar cheese, 1 tsp mustard, 2 slices avocado.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack – 1 container Greek yogurt, 1/2 cup raspberries and 28 g pretzels.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dinner – 113 g chicken breast, 1 cup white rice, 1/2 chopped bell pepper, green onion, 1/2 red onion, 1/2 cup mushrooms, 2 tbsp soy sauce and 1 egg")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Total intake for the day: Calories: 2448. Fat: 79 g, Carbs: 301 g, Protein: 134 g")
                ElseIf myRnd = 4 Then
                    LstDisplayDP.Items.Add("Breakfast – 1 cup of oats, 1 cup low-fat milk, 1.5 cups of coffee, 1 tbsp half and half cream, 2 medium oranges and 1 tsp of sugar.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack – 1 medium-sized banana and 3 tbsp of peanut butter")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch – 1 medium-sized apple, 3 slices of whole wheat bread, 28 g of cheddar cheese, 1 lettuce leaf, 1.5 cups of tea, 57 g of turkey breast")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack – 2 slices of rye bread, 1 tbsp of mayonnaise, 1/2 cup of tuna and 1 medium peach.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dinner – 113 g of salmon, 1 cup of brown rice, 2 cups of skim milk, 1 large garden salad and 4 tbsp honey mustard.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Total intake for the day: Calories: 2568. Fat: 72 g, Carbs: 385 g, Protein: 118.2 g")
                ElseIf myRnd = 5 Then
                    LstDisplayDP.Items.Add("Breakfast – 1/2 cup of oats, 1 cup of strawberries, 1 large egg and 3 egg whites (boiled), 1.25 cups of almond milk and 1 scoop of whey protein.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack – 227 g of shredded chicken breast, 2 low-carb whole-wheat wraps and 1 cup of bell peppers.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch – 4 cups of romaine lettuce and spinach mix, 12 grape tomatoes, 2 reduced-fat cheese sticks, 150 g Greek yogurt and 1 cup of roasted almonds.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack – 1.25 cups of unsweetened almond milk, 1 scoop of whey protein, 150 g of greek yogurt and 1 cup of mixed frozen fruits.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack – 1 scoop of whey protein mixed with water.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dinner – 226 g of lean ground beef, 1/2 cup of brown rice and 2 cups of steamed broccoli.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dessert: 1 cup of low-fat cottage cheese and 1 cup of strawberries.")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Total intake for the day: Calories: 2,456. Fat: 67 g, Carbs: 208 g, Protein: 281 g")
                End If
            ElseIf fitness.FitnessGoal > 2000 Then
                LstDisplayDP.Items.Add("Diet Plan: ")
                LstDisplayDP.Items.Add("")
                If myRnd = 1 Then
                    LstDisplayDP.Items.Add("Breakfast - 2 eggs, 20g of spinach, 24g of mushrooms, 23g of broccoli, 205g of sautéed sweet potatoes, 1 tablespoon of olive oil")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack - Apple, 2 tablespoons of peanut butter")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch - 1 pita, 140g of tuna, chopped red onion, 1/4 avocado, 1 tablespoon of feta cheese")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack - 56g of cheddar cheese, 92g of grapes")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dinner - 140g of baked salmon, 2 tablespoons of olive oil, 82g of rice, 180g of asparagus, 100g of roasted eggplant")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Total intake for the day: Calories: 2,027. Fat: 22 g, Carbs: 129 g, Protein: 185.8 g")
                ElseIf myRnd = 2 Then
                    LstDisplayDP.Items.Add("Breakfast - 2 slices of whole-grain toast, 2 tablespoons of almond butter, 1 banana, cinnamon")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack - 3/4 cup milk, 20g of spinach, 42g of protein powder, 123g of frozen blueberries, 1 tablespoon of hemp seeds")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch - 1/2 avocado, 140g of tuna, 75g of tomatoes 100g of mixed greens")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack - fresh carrot and celery sticks, 2 tablespoons of hummus")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dinner - 140g of chicken 176g of broccoli, 82g of cooked brown rice, 1 tablespoonof soy sauce")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Total intake for the day:  Calories: 1,913. Fat: 29.3 g, Carbs: 211.9 g, Protein: 153.7 g")
                ElseIf myRnd = 3 Then
                    LstDisplayDP.Items.Add("Breakfast - 200g of yogurt, 74g of blueberries, 76g of sliced strawberries, 30g of granola")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack - 1 banana, 1 and 1/2 tablespoons of almond butter")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch - 132g of cooked rice noodles, 141g of tofu, 2 teaspoons  tamari, 1/2 teaspoon of Sriracha, 2 teaspoons of honey")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack - protein bar of choice")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dinner - 3 corn tortillas, 170g of grilled cod, 1/2 avocado, 2 tablespoons of pico de gallo")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Total intake for the day: Calories: 2005. Fat: 49 g, Carbs: 201 g, Protein: 124 g")
                ElseIf myRnd = 4 Then
                    LstDisplayDP.Items.Add("Breakfast - 1/2 avocado, 2 slices of toast, 1 tablespoon of olive oil, 1 egg")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack - 200g of plain Greek yogurt, 125g of strawberries")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch- 93g of cooked quinoa, 142g of grilled chicken, 1 tablespoon of olive oil1, 180g of mixed vegetables")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack - 2 squares of dark chocolate, 15–20 almonds")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dinner - 30g of kidney beans, 103g of butternut squash, 75g of cooked sweet corn, 1/4 of a jalapeño pepper")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Total intake for the day: Calories: 1945. Fat: 32 g, Carbs: 185 g, Protein: 108.7 g")
                ElseIf myRnd = 5 Then
                    LstDisplayDP.Items.Add("Breakfast - 80g of steel-cut oats, 1 tablespoonof hemp seeds, 1 tablespoon of flax seeds, 2 tablespoons of dried cherrie")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack - 1/2 bell pepper, 1 cup of carrots, 4 tablespoons of guacamoler")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Lunch - 1 tortilla, 60g of red peppers, 5 slices of grilled zucchini, 84g of fresh mozzarella")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Snack - 170g of chia pudding, 1/2 of a sliced banana")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Dinner - 2 tablespoons of pesto, 1/2 cup of whole-wheat or brown-rice penne, 170g of shrimp, 1 tablespoon of Parmesan cheese")
                    LstDisplayDP.Items.Add("")
                    LstDisplayDP.Items.Add("Total intake for the day: Calories: 2,017. Fat: 22 g, Carbs: 129 g, Protein: 185.8 g")
                End If
            End If
        End While
        connection.Close()


    End Sub
    Sub InsertionSort()
        Dim fitness(9) As Fitness
        Dim tempFitness As Fitness
        Dim currentPosition As Integer
        Dim newPosition As Integer

        For currentPosition = 1 To 9
            tempFitness = fitness(currentPosition)
            newPosition = currentPosition
            While newPosition > 0 AndAlso fitness(newPosition - 1).FitnessGoal > tempFitness.FitnessGoal
                fitness(newPosition) = fitness(newPosition - 1)
                newPosition = newPosition - 1
            End While
            fitness(newPosition) = tempFitness
        Next
        MsgBox("Data Sorted")
    End Sub
End Class