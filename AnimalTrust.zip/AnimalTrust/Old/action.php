<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "wildscottrust";

$conn = mysqli_connect($servername, $username, $password, $database);

$ANIMAL = $_GET["AnimalSearch"];

$sql = "SELECT AnimalID, AnimalName, Category, BestPlaceToSee FROM animals WHERE AnimalName = '".$ANIMAL."'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) 
    {
    echo "<table border=1><tr><th>AnimalID</th><th>AnimalName</th></tr><th>Category</th></tr><th>BestPlaceToSee</th></tr>";
    
    while($row = mysqli_fetch_assoc($result))
    {
        echo "<tr><td>". $row["AnimalID"]. "</td><td>" . $row["AnimalName"]. "</td></tr>" . $row["Category"]. "</td></tr>" . $row["BestPlaceToSee"]. "</td></tr>";
    }
    echo "</table>";
}

else {
        echo "0 results";
    }


if ($conn)
{
    echo "Connected Successfully";
}
else {
    echo "Connection Failed";
}



mysqli_close($conn);
?>