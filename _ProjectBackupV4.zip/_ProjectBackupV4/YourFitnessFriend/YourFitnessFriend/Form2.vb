﻿Imports MySql.Data.MySqlClient
Public Class Form2
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCreate.Click
        Dim connection As MySqlConnection
        Dim command As MySqlCommand
        Dim connectionString As String = "server=localhost;user=root;password=;database=YourFitnessFriend"

        connection = New MySqlConnection(connectionString)
        Dim Username = EnterUsername.Text
        Dim Password = EnterPassword.Text

        connection = New MySqlConnection(connectionString)
        command = New MySqlCommand("INSERT INTO UserLogin (UsernameData, PasswordData) VALUES('" & Username & "','" & Password & "')")
        command.Connection = connection

        connection.Open()
        If Len(Username) >= 8 Or Len(Password) >= 8 Then
            command.ExecuteNonQuery()
            MsgBox("Account Created")
            Me.Hide()
            Form1.Show()
        ElseIf Username <> "" Or Password <> "" Then
            MsgBox("Error - Please Enter a Username and Password Greater Than 8 Characters")
        ElseIf Username = "" Or Password = "" Then
            MsgBox("Error - Please Enter a Username and Password")
        End If
        connection.Close()
    End Sub

    Private Sub BtnHome_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnHome.Click
        Me.Hide()
        Form1.Show()
    End Sub
End Class