﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BtnFitnessData = New System.Windows.Forms.Button()
        Me.BtnAction = New System.Windows.Forms.Button()
        Me.BtnHelp = New System.Windows.Forms.Button()
        Me.BtnLogOut = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(302, 84)
        Me.PictureBox1.TabIndex = 16
        Me.PictureBox1.TabStop = False
        '
        'BtnFitnessData
        '
        Me.BtnFitnessData.Image = CType(resources.GetObject("BtnFitnessData.Image"), System.Drawing.Image)
        Me.BtnFitnessData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnFitnessData.Location = New System.Drawing.Point(12, 183)
        Me.BtnFitnessData.Name = "BtnFitnessData"
        Me.BtnFitnessData.Size = New System.Drawing.Size(271, 85)
        Me.BtnFitnessData.TabIndex = 17
        Me.BtnFitnessData.Text = "Enter Fitness Data"
        Me.BtnFitnessData.UseVisualStyleBackColor = True
        '
        'BtnAction
        '
        Me.BtnAction.Image = CType(resources.GetObject("BtnAction.Image"), System.Drawing.Image)
        Me.BtnAction.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnAction.Location = New System.Drawing.Point(325, 183)
        Me.BtnAction.Name = "BtnAction"
        Me.BtnAction.Size = New System.Drawing.Size(271, 85)
        Me.BtnAction.TabIndex = 18
        Me.BtnAction.Text = "Action Plan"
        Me.BtnAction.UseVisualStyleBackColor = True
        '
        'BtnHelp
        '
        Me.BtnHelp.Image = CType(resources.GetObject("BtnHelp.Image"), System.Drawing.Image)
        Me.BtnHelp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnHelp.Location = New System.Drawing.Point(634, 183)
        Me.BtnHelp.Name = "BtnHelp"
        Me.BtnHelp.Size = New System.Drawing.Size(271, 85)
        Me.BtnHelp.TabIndex = 19
        Me.BtnHelp.Text = "Help"
        Me.BtnHelp.UseVisualStyleBackColor = True
        '
        'BtnLogOut
        '
        Me.BtnLogOut.Image = CType(resources.GetObject("BtnLogOut.Image"), System.Drawing.Image)
        Me.BtnLogOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnLogOut.Location = New System.Drawing.Point(738, 12)
        Me.BtnLogOut.Name = "BtnLogOut"
        Me.BtnLogOut.Size = New System.Drawing.Size(167, 47)
        Me.BtnLogOut.TabIndex = 20
        Me.BtnLogOut.Text = "Log Out"
        Me.BtnLogOut.UseVisualStyleBackColor = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(164, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(917, 443)
        Me.Controls.Add(Me.BtnLogOut)
        Me.Controls.Add(Me.BtnHelp)
        Me.Controls.Add(Me.BtnAction)
        Me.Controls.Add(Me.BtnFitnessData)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form3"
        Me.Text = "Form3"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents BtnFitnessData As System.Windows.Forms.Button
    Friend WithEvents BtnAction As System.Windows.Forms.Button
    Friend WithEvents BtnHelp As System.Windows.Forms.Button
    Friend WithEvents BtnLogOut As System.Windows.Forms.Button
End Class
