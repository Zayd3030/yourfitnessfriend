﻿Public Class FitnessData
    Public id As Integer
    Public Gender As String
    Public Weight As Integer
    Public Height As Integer
    Public Age As Integer
    Public Exercise As String
    Public LoseOrGain As String
    Public BMR As Integer
    Public ExerciseBMR As Integer
    Public FitnessGoal As Integer

    Public Sub New(ByVal id As Integer, ByVal Gender As String, ByVal Weight As Integer, ByVal Height As Integer, ByVal Age As Integer, ByVal Exercise As String, ByVal LoseOrGain As String)
        Me.id = id
        Me.Gender = Gender
        Me.Weight = Weight
        Me.Height = Height
        Me.Age = Age
        Me.Exercise = Exercise
        Me.LoseOrGain = LoseOrGain
    End Sub
    Public Sub UpdateWeight(ByVal NewWeight As Integer)
        Me.Weight = NewWeight
    End Sub

    Public Sub UpdateAge(ByVal NewAge As Integer)
        Me.Age = NewAge
    End Sub

    Public Sub UpdateExercise(ByVal NewExercise As String)
        Me.Exercise = NewExercise
    End Sub
    Public Function GetId(ByVal id As Integer)
        Return id
    End Function

    Public Function GetGender(ByVal Gender As String)
        Return Gender
    End Function

    Public Function GetWeight(ByVal Weight As String)
        Return Weight
    End Function

    Public Function GetHeight(ByVal Height As String)
        Return Height
    End Function

    Public Function GetAge(ByVal Age As String)
        Return Age
    End Function

    Public Function GetExercise(ByVal Exercise As String)
        Return Exercise
    End Function

    Public Function GetLoseOrGain(ByVal LoseOrGain As String)
        Return LoseOrGain
    End Function

    Public Function GetBMR(ByVal BMR As String)
        Return BMR
    End Function

    Public Function GetExerciseBMR(ByVal ExerciseBMR As String)
        Return ExerciseBMR
    End Function

    Public Function GetFitnessGoal(ByVal FitnessGoal As String)
        Return FitnessGoal
    End Function
End Class
