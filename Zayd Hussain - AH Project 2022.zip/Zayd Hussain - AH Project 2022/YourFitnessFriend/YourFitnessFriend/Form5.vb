﻿Imports MySql.Data.MySqlClient
Public Class Form5
    Private Sub BtnFitnessData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFitnessData.Click
        Dim Person1 As New FitnessData(0, ComboBoxGender.Text, TextBoxWeight.Text, TextBoxHeight.Text, TextBoxAge.Text, ComboBoxExercise.Text, ComboBoxLoseOrGain.Text)
        If Person1.Gender = "Male" Then
            Person1.BMR = 66 + (13.7 * Person1.Weight) + (5 * Person1.Height) - (6.8 * Person1.Age)
        ElseIf Person1.Gender = "Female" Then
            Person1.BMR = 655 + (9.6 * Person1.Weight) + (1.8 * Person1.Height) - (4.7 * Person1.Age)
        End If

        If Person1.Exercise = "Sedentary" Then
            Person1.ExerciseBMR = Person1.BMR * 1.2
        ElseIf Person1.Exercise = "Lightly" Then
            Person1.ExerciseBMR = Person1.BMR * 1.375
        ElseIf Person1.Exercise = "Moderately" Then
            Person1.ExerciseBMR = Person1.BMR * 1.55
        ElseIf Person1.Exercise = "VeryActive" Then
            Person1.ExerciseBMR = Person1.BMR * 1.725
        ElseIf Person1.Exercise = "ExtraActive" Then
            Person1.ExerciseBMR = Person1.BMR * 1.9
        End If

        If Person1.LoseOrGain = "Lose" Then
            Person1.FitnessGoal = Person1.ExerciseBMR - 300
        ElseIf Person1.LoseOrGain = "Gain" Then
            Person1.FitnessGoal = Person1.ExerciseBMR + 300
        End If


        LstDisplayBMR.Items.Add("Your Natural BMR is = " & Person1.BMR)
        LstDisplayBMR.Items.Add("Your BMR is = " & Person1.ExerciseBMR)
        LstDisplayFG.Items.Add("Your Fitness Goal is = " & Person1.FitnessGoal)

        Call SendData(Person1)
    End Sub

    Private Sub BtnHome_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnHome.Click
        EnterUsername.Clear()
        TextBoxHeight.Clear()
        TextBoxWeight.Clear()
        TextBoxAge.Clear()
        ComboBoxExercise.SelectedIndex = -1
        ComboBoxGender.SelectedIndex = -1
        ComboBoxLoseOrGain.SelectedIndex = -1
        LstDisplayBMR.Items.Clear()
        LstDisplayFG.Items.Clear()
        Me.Hide()
        Form3.Show()
    End Sub
    Sub SendData(ByVal Person1 As FitnessData)
        
        Dim id = Person1.id
        Dim Gender = Person1.Gender
        Dim Weight = Person1.Weight
        Dim Height = Person1.Height
        Dim Age = Person1.Age
        Dim Exercise = Person1.Exercise
        Dim LoseOrGain = Person1.LoseOrGain
        Dim BMR = Person1.BMR
        Dim ExerciseBMR = Person1.ExerciseBMR
        Dim FitnessGoal = Person1.FitnessGoal
        Dim Newid As Integer
        Dim UsernameEnter As String = EnterUsername.Text

        Dim connection As MySqlConnection
        Dim command As MySqlCommand
        Dim connectionString As String = "server=localhost;user=root;password=;database=YourFitnessFriend"
        Dim reader As MySqlDataReader

        connection = New MySqlConnection(connectionString)

        connection.Open()
        command = New MySqlCommand("SELECT UserId FROM UserLogin WHERE UsernameData ='" & UsernameEnter & "'")
        command.Connection = connection
        reader = command.ExecuteReader

        While reader.Read()
            Newid = reader.Item("UserId")
        End While
        connection.Close()


        connection.Open()
        command = New MySqlCommand("INSERT INTO FitnessData(UserId, Gender, Weight, Height, Age, Exercise, LoseOrGain, BMR, ExerciseBMR, FitnessGoal) VALUES('" & Newid & "','" & Gender & "','" & Weight & "','" & Height & "','" & Age & "','" & Exercise & "','" & LoseOrGain & "','" & BMR & "','" & ExerciseBMR & "','" & FitnessGoal & "')")
        command.Connection = connection
        If Person1.Weight < 45 Then
            MsgBox("Error - Please Enter a Weight Over 45 KG")
        ElseIf Person1.Height < 120 Then
            MsgBox("Error - Please Enter a Height Over 120 CM")
        ElseIf Person1.Age < 16 Then
            MsgBox("Error - Please Enter an Age Over 16")
        Else
            command.ExecuteNonQuery()
            MsgBox("Data Added")
            MsgBox("Your ID is " & Newid)

            EnterUsername.Clear()
            TextBoxHeight.Clear()
            TextBoxWeight.Clear()
            TextBoxAge.Clear()
            ComboBoxExercise.SelectedIndex = -1
            ComboBoxGender.SelectedIndex = -1
            ComboBoxLoseOrGain.SelectedIndex = -1
            LstDisplayBMR.Items.Clear()
            LstDisplayFG.Items.Clear()

        End If

        connection.Close()
    End Sub
End Class