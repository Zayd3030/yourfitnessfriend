﻿Public Class Form3

    Private Sub BtnLogOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLogOut.Click
        Me.Hide()
        Form4.Show()
    End Sub

    Private Sub BtnFitnessData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFitnessData.Click
        Me.Hide()
        Form5.Show()
    End Sub

    Private Sub BtnAction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAction.Click
        Me.Hide()
        Form6.Show()
    End Sub

    Private Sub BtnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnHelp.Click
        Me.Hide()
        Form7.Show()
    End Sub
End Class