﻿Imports MySql.Data.MySqlClient
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLogin.Click
        Dim connection As MySqlConnection
        Dim command As MySqlCommand
        Dim connectionString As String = "server=localhost;user=root;password=;database=YourFitnessFriend"
        Dim reader As MySqlDataReader

        connection = New MySqlConnection(connectionString)
        connection.Open()
        command = New MySqlCommand("SELECT * FROM UserLogin WHERE UsernameData='" & EnterUsername.Text & "' AND PasswordData='" & EnterPassword.Text & "'")
        command.Connection = connection
        reader = command.ExecuteReader()

        While reader.Read()
            Dim GetUsername As String = reader.GetString(1).ToString
            Dim GetPassword As String = reader.GetString(2).ToString

            If GetUsername = EnterUsername.Text And GetPassword = EnterPassword.Text Then
                MsgBox("Login Successful")
                EnterUsername.Clear()
                EnterPassword.Clear()
                Me.Hide()
                Form3.Show()
            ElseIf GetUsername <> EnterUsername.Text And GetPassword <> EnterPassword.Text Then
                MsgBox("Login Failed")
            End If

        End While
        connection.Close()
    End Sub

    Private Sub RegisterBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegisterBtn.Click
        Me.Hide()
        Form2.Show()
    End Sub
End Class
