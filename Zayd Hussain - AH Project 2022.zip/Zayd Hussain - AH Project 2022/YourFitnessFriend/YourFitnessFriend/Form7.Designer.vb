﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form7
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form7))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.EnterID = New System.Windows.Forms.TextBox()
        Me.BtnLoad = New System.Windows.Forms.Button()
        Me.LstDisplayLoseOrGain = New System.Windows.Forms.ListBox()
        Me.LstDisplayMuscle = New System.Windows.Forms.ListBox()
        Me.LstDisplayGym = New System.Windows.Forms.ListBox()
        Me.LstDisplayCardio = New System.Windows.Forms.ListBox()
        Me.BtnHome = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(306, 91)
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(564, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 41)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Help"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(567, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 22)
        Me.Label4.TabIndex = 44
        Me.Label4.Text = "Enter ID"
        '
        'EnterID
        '
        Me.EnterID.Location = New System.Drawing.Point(552, 106)
        Me.EnterID.Name = "EnterID"
        Me.EnterID.Size = New System.Drawing.Size(110, 20)
        Me.EnterID.TabIndex = 43
        '
        'BtnLoad
        '
        Me.BtnLoad.Image = CType(resources.GetObject("BtnLoad.Image"), System.Drawing.Image)
        Me.BtnLoad.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnLoad.Location = New System.Drawing.Point(334, 370)
        Me.BtnLoad.Name = "BtnLoad"
        Me.BtnLoad.Size = New System.Drawing.Size(572, 65)
        Me.BtnLoad.TabIndex = 45
        Me.BtnLoad.Text = "Load Results"
        Me.BtnLoad.UseVisualStyleBackColor = True
        '
        'LstDisplayLoseOrGain
        '
        Me.LstDisplayLoseOrGain.FormattingEnabled = True
        Me.LstDisplayLoseOrGain.Location = New System.Drawing.Point(27, 164)
        Me.LstDisplayLoseOrGain.Name = "LstDisplayLoseOrGain"
        Me.LstDisplayLoseOrGain.Size = New System.Drawing.Size(518, 186)
        Me.LstDisplayLoseOrGain.TabIndex = 46
        '
        'LstDisplayMuscle
        '
        Me.LstDisplayMuscle.FormattingEnabled = True
        Me.LstDisplayMuscle.Location = New System.Drawing.Point(551, 164)
        Me.LstDisplayMuscle.Name = "LstDisplayMuscle"
        Me.LstDisplayMuscle.Size = New System.Drawing.Size(212, 186)
        Me.LstDisplayMuscle.TabIndex = 47
        '
        'LstDisplayGym
        '
        Me.LstDisplayGym.FormattingEnabled = True
        Me.LstDisplayGym.Location = New System.Drawing.Point(769, 164)
        Me.LstDisplayGym.Name = "LstDisplayGym"
        Me.LstDisplayGym.Size = New System.Drawing.Size(253, 186)
        Me.LstDisplayGym.TabIndex = 48
        '
        'LstDisplayCardio
        '
        Me.LstDisplayCardio.FormattingEnabled = True
        Me.LstDisplayCardio.Location = New System.Drawing.Point(1032, 164)
        Me.LstDisplayCardio.Name = "LstDisplayCardio"
        Me.LstDisplayCardio.Size = New System.Drawing.Size(189, 186)
        Me.LstDisplayCardio.TabIndex = 49
        '
        'BtnHome
        '
        Me.BtnHome.Image = CType(resources.GetObject("BtnHome.Image"), System.Drawing.Image)
        Me.BtnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnHome.Location = New System.Drawing.Point(1054, 12)
        Me.BtnHome.Name = "BtnHome"
        Me.BtnHome.Size = New System.Drawing.Size(167, 47)
        Me.BtnHome.TabIndex = 50
        Me.BtnHome.Text = "Home"
        Me.BtnHome.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(557, 139)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(206, 22)
        Me.Label1.TabIndex = 51
        Me.Label1.Text = "How To Gain Muscle:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(150, 139)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(255, 22)
        Me.Label2.TabIndex = 52
        Me.Label2.Text = "How to lose / Gain Weight?"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(825, 139)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(155, 22)
        Me.Label3.TabIndex = 53
        Me.Label3.Text = "Gym Work Outs"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(1028, 139)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(205, 22)
        Me.Label6.TabIndex = 54
        Me.Label6.Text = "Best Cardio Exercise"
        '
        'Form7
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(164, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1233, 464)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnHome)
        Me.Controls.Add(Me.LstDisplayCardio)
        Me.Controls.Add(Me.LstDisplayGym)
        Me.Controls.Add(Me.LstDisplayMuscle)
        Me.Controls.Add(Me.LstDisplayLoseOrGain)
        Me.Controls.Add(Me.BtnLoad)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.EnterID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PictureBox1)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Name = "Form7"
        Me.Text = "Form7"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents EnterID As System.Windows.Forms.TextBox
    Friend WithEvents BtnLoad As System.Windows.Forms.Button
    Friend WithEvents LstDisplayLoseOrGain As System.Windows.Forms.ListBox
    Friend WithEvents LstDisplayMuscle As System.Windows.Forms.ListBox
    Friend WithEvents LstDisplayGym As System.Windows.Forms.ListBox
    Friend WithEvents LstDisplayCardio As System.Windows.Forms.ListBox
    Friend WithEvents BtnHome As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
